export interface Player {
    name: string;
    color: string;
    score: number;
  }

  
  