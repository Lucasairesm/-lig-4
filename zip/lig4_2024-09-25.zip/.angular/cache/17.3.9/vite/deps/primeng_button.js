import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-ARWHNC26.js";
import "./chunk-LX7PMAWX.js";
import "./chunk-YH3NFU6Q.js";
import "./chunk-GFZWSJ3F.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-AWAQQT3D.js";
import "./chunk-LGAY4YQG.js";
import "./chunk-ZS7RCKF3.js";
import "./chunk-OBCKPMKI.js";
import "./chunk-J4B6MK7R.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
