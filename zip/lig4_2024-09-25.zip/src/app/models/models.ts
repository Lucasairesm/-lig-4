export interface Player {
    nome: string;
    cor: string;
    pontos: number;
  }


